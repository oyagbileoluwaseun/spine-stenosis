import io, os, json, base64, datetime, textwrap
from typing import List, Optional, Dict

import numpy as np
import requests
from PIL import Image

import streamlit as st
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm

# ====== Optional LLM (Gemini) ======
GEMINI_API_KEY = (
    os.environ.get("GEMINI_API_KEY")
    or st.secrets.get("GEMINI_API_KEY", "")
)
try:
    import google.genai as genai
    _g_client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None
except Exception:
    _g_client = None

# ====== DuckDuckGo search (new + old packages supported) ======
_DDG_OK = True
try:
    from ddgs import DDGS
except Exception:
    try:
        from duckduckgo_search import DDGS
    except Exception:
        _DDG_OK = False

# ====== API config ======
API_BASE = st.secrets.get("API_BASE", os.environ.get("API_BASE", "")).rstrip("/")
API_INFER = f"{API_BASE}/infer" if API_BASE else ""


# --------------------------------------------------------------------------------------
# Utilities
# --------------------------------------------------------------------------------------
def _b64_png(pil_img: Image.Image) -> str:
    buf = io.BytesIO()
    pil_img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


def _bytes_to_png(pil_img: Image.Image) -> bytes:
    buf = io.BytesIO()
    pil_img.save(buf, format="PNG")
    return buf.getvalue()


def _contrast_and_blur_metrics(img_rgb: Image.Image) -> Dict[str, float | list]:
    """
    Local QA metrics w/o OpenCV. The blur score is variance of a discrete
    Laplacian computed with pure NumPy (so no cv2 errors on some machines).

    Returns:
      {"contrast_std": float, "blur_var": float, "flags": [..]}
    """
    g = np.asarray(img_rgb.convert("L"), dtype=np.float32) / 255.0
    contrast_std = float(np.std(g))

    # Discrete 4-neighbor Laplacian: up+down+left+right - 4*center
    g_pad = np.pad(g, 1, mode="edge")
    up    = g_pad[:-2, 1:-1]
    down  = g_pad[2:,  1:-1]
    left  = g_pad[1:-1, :-2]
    right = g_pad[1:-1, 2:]
    lap   = (up + down + left + right) - 4.0 * g_pad[1:-1, 1:-1]
    blur_var = float(np.var(lap))

    flags = []
    if contrast_std < 0.07:
        flags.append("low contrast")
    if blur_var < 0.0007:
        flags.append("blurry")
    if not flags:
        flags = ["OK"]
    return {"contrast_std": contrast_std, "blur_var": blur_var, "flags": flags}


def _fetch_refs(query: str, n=3) -> List[dict]:
    if not _DDG_OK:
        return []
    safe = [
        "radiopaedia.org",
        "nih.gov",
        "nice.org.uk",
        "who.int",
        "ncbi.nlm.nih.gov",
        "pmc.ncbi.nlm.nih.gov",
    ]
    q = f"{query} site:{' OR site:'.join(safe)}"
    try:
        with DDGS(timeout=8) as ddg:
            hits = ddg.text(q, max_results=8)
    except Exception:
        return []
    out = []
    for h in hits or []:
        url = h.get("href") or h.get("url") or ""
        title = h.get("title") or h.get("body") or "Reference"
        if any(d in url for d in safe):
            out.append({"title": title.strip(), "href": url})
        if len(out) >= n:
            break
    return out


def _fallback_sections(prob_json: dict) -> dict:
    sev = (prob_json.get("severity") or "").lower()
    p_none  = prob_json.get("none", 0.0)
    p_mild  = prob_json.get("mild", 0.0)
    p_sev   = prob_json.get("severe", 0.0)

    clinician = [
        f"Model-assessed severity: **{sev.upper()}**.",
        f"Probabilities – none: {p_none:.3f}, mild: {p_mild:.3f}, severe: {p_sev:.3f}.",
        "Findings are derived from a 3D CNN ensemble with Grad-CAM evidence.",
        "Use alongside clinical assessment and full imaging review."
    ]
    patient = (
        "This tool estimates whether your spinal canal looks narrowed (‘stenosis’) on the scan. "
        f"Your result suggests **{sev}** changes. This is **not** a diagnosis. "
        "Only your clinician can confirm what it means for you after considering symptoms and exam."
    )
    caveats = [
        "Research tool – not cleared for clinical use.",
        "Image quality, artifacts and anatomy can affect results.",
        "Discuss all results and next steps with a qualified clinician."
    ]
    return {
        "clinician": "- " + "\n- ".join(clinician),
        "patient": textwrap.fill(patient, 100),
        "caveats": "- " + "\n- ".join(caveats),
    }


def _gemini_sections(prob_json: dict, overlay_png_bytes: Optional[bytes]) -> dict:
    """
    Ask Gemini; if unavailable or fails, return robust fallback text.
    """
    if not _g_client:
        return _fallback_sections(prob_json)

    parts = [{
        "text": (
            "You are a medical assistant summarizing a computer-vision score for spinal stenosis severity.\n"
            "Write three concise parts:\n"
            "1) Clinician-style summary (2–4 bullets)\n"
            "2) Patient-friendly explanation (≤ 120 words)\n"
            "3) Caveats & next steps (bullets; not medical advice)\n\n"
            f"Probabilities JSON:\n{json.dumps(prob_json, indent=2)}\n"
            "If an image is attached, it is a Grad-CAM overlay heatmap."
        )
    }]
    if overlay_png_bytes:
        parts.append({
            "inline_data": {
                "mime_type": "image/png",
                "data": base64.b64encode(overlay_png_bytes).decode()
            }
        })

    try:
        r = _g_client.models.generate_content(
            model="gemini-1.5-flash",
            contents=[{"role": "user", "parts": parts}],
            safety_settings={"HARASSMENT": "block_none", "HATE_SPEECH": "block_none",
                             "SEXUAL": "block_none", "DANGEROUS": "block_none"},
        )
        text = (r.candidates[0].content.parts[0].text or "").strip()
    except Exception:
        return _fallback_sections(prob_json)

    def _grab(label, default=None):
        i = text.lower().find(label)
        if i < 0:
            return default
        return text[i:].strip()

    clin = _grab("clinician") or text
    pat  = _grab("patient")   or None
    cav  = _grab("caveat")    or None
    return {"clinician": clin, "patient": pat or _fallback_sections(prob_json)["patient"],
            "caveats": cav or _fallback_sections(prob_json)["caveats"]}


def _make_case_pdf(meta: dict, probs: dict, cutpoint: float, severity: str,
                   clinician: Optional[str], patient: Optional[str],
                   caveats: Optional[str], overlay_png: Optional[bytes]) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    W, H = A4
    m = 16 * mm
    y = H - m

    def writeln(txt, size=11, leading=14):
        nonlocal y
        c.setFont("Helvetica", size)
        for line in (txt or "").splitlines():
            c.drawString(m, y, line[:110])
            y -= leading

    c.setFont("Helvetica-Bold", 14)
    c.drawString(m, y, "Spine Stenosis – Case Report")
    y -= 18
    writeln(f"Generated: {datetime.datetime.utcnow():%Y-%m-%d %H:%M UTC}")
    writeln(f"Patient ID: {meta.get('case_id','N/A')}")
    y -= 6
    c.setFont("Helvetica-Bold", 12)
    c.drawString(m, y, f"Predicted severity: {severity.upper()}")
    y -= 16
    writeln(f"Cut-point: {cutpoint:.2f}")
    writeln("Probabilities:")
    for k, v in probs.items():
        writeln(f"• {k}: {v:.3f}")
    y -= 8

    c.setFont("Helvetica-Bold", 12)
    c.drawString(m, y, "1) Clinician-style summary")
    y -= 16
    writeln(clinician or "—")
    y -= 6

    c.setFont("Helvetica-Bold", 12)
    c.drawString(m, y, "2) Patient-friendly explanation")
    y -= 16
    writeln(patient or "—")
    y -= 6

    c.setFont("Helvetica-Bold", 12)
    c.drawString(m, y, "3) Caveats & next steps")
    y -= 16
    writeln(caveats or "—")
    y -= 10

    if overlay_png and y > 120:
        try:
            img_buf = io.BytesIO(overlay_png)
            w = W - 2 * m
            h = w * 0.55
            c.drawImage(img_buf, m, y - h, width=w, height=h,
                        preserveAspectRatio=True, mask='auto')
            y -= h + 12
        except Exception:
            pass

    c.setFont("Helvetica-Oblique", 9)
    c.drawString(m, 16 * mm,
                 "Disclaimer: Experimental research UI – not for clinical use. Always consult a qualified clinician.")
    c.showPage()
    c.save()
    return buf.getvalue()


def post_infer(file_name: str, file_bytes: bytes, patient_id: str) -> dict:
    if not API_INFER:
        raise RuntimeError("API_BASE is not configured.")
    files = {"file": (file_name, file_bytes)}
    r = requests.post(API_INFER, files=files, timeout=120)
    r.raise_for_status()
    return r.json()


# --------------------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------------------
st.set_page_config(page_title="Spinal Stenosis – Client", layout="wide")

with st.sidebar:
    st.markdown("### Settings")
    st.text_input("API Base (read-only)", API_BASE, disabled=True)
    st.markdown(
        "<div style='padding:.6rem;border:1px solid #666;border-radius:6px;'>"
        "<b>Disclaimer:</b> This UI is for research/education only and must not be used for diagnosis or treatment. "
        "Results are model outputs for discussion with a clinician.</div>",
        unsafe_allow_html=True
    )

st.title("Upload Scan")
st.caption("Accepted: **NIfTI (.nii/.nii.gz) or NPZ**")

uploaded = st.file_uploader("Drag a scan here …", type=["nii", "nii.gz", "npz"], label_visibility="collapsed")
patient_id = st.text_input("Patient ID", value=f"case-{int(datetime.datetime.utcnow().timestamp())}")

overlay_img: Optional[Image.Image] = None
overlay_png_bytes: Optional[bytes] = None
out = None

col_btn, _ = st.columns([0.25, 0.75])
with col_btn:
    run_clicked = st.button("Run Inference", type="primary", use_container_width=True, disabled=not uploaded)

if run_clicked and uploaded:
    with st.spinner("Running inference…"):
        try:
            out = post_infer(uploaded.name, uploaded.getvalue(), patient_id)
            st.session_state["last_out"] = out
        except Exception as e:
            st.error(f"Backend returned an error:\n\n{e}")
            out = None

if out is None and "last_out" in st.session_state:
    out = st.session_state["last_out"]

st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

if out:
    colL, colR = st.columns([0.56, 0.44], gap="large")

    # ---------------- Left: Image evidence ----------------
    with colL:
        st.subheader("Grad-CAM overlay")
        b64 = out.get("evidence", {}).get("gradcam_resnet3d_png")
        if b64:
            overlay_png_bytes = base64.b64decode(b64)
            overlay_img = Image.open(io.BytesIO(overlay_png_bytes)).convert("RGB")
            st.image(overlay_img, caption="Grad-CAM overlay", width='stretch')
        else:
            st.info("No overlay returned.")

    # ---------------- Right: Predictions + narratives ----------------
    with colR:
        st.subheader("Prediction")
        # Pretty block with key info
        probs = out.get("probabilities", {})
        cutp = out.get("meta", {}).get("cutpoints", {}).get("mild_severe", 0.65)
        sev  = out.get("severity", "unknown")

        st.markdown(
            f"""
            <div style="padding:.8rem;border:1px solid #555;border-radius:8px">
            <div><b>Predicted severity:</b> {sev.upper()}</div>
            <div><b>Cut-point:</b> {cutp:.2f}</div>
            <div><b>Probabilities:</b></div>
            <ul style="margin-top:.2rem">
              <li>none: {probs.get('none',0):.3f}</li>
              <li>mild: {probs.get('mild',0):.3f}</li>
              <li>severe: {probs.get('severe',0):.3f}</li>
            </ul>
            </div>
            """,
            unsafe_allow_html=True
        )

        # raw JSON (collapsed)
        st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)
        with st.expander("Raw response (JSON)"):
            st.json(out, expanded=False)

        sections = _gemini_sections({"severity": sev, **probs}, overlay_png_bytes)

        st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
        with st.expander("Clinician-style summary", expanded=False):
            st.markdown(sections["clinician"])

        with st.expander("Patient-friendly explanation", expanded=False):
            st.markdown(sections["patient"])

        with st.expander("Caveats & next steps", expanded=False):
            st.markdown(sections["caveats"])

        st.subheader("🔎 Auto-references (trusted medical sources)")
        refs = _fetch_refs(f"{sev} spinal stenosis management", n=3)
        if not refs:
            st.caption("Could not fetch references (search timeout or network limits).")
        else:
            for r in refs:
                st.markdown(f"- [{r['title']}]({r['href']})")

    st.divider()

    # ---------------- PDF download ----------------
    meta = {"case_id": out.get("case_id", patient_id)}
    pdf_bytes = _make_case_pdf(
        meta=meta, probs=probs, cutpoint=cutp, severity=sev,
        clinician=sections.get("clinician"),
        patient=sections.get("patient"),
        caveats=sections.get("caveats"),
        overlay_png=overlay_png_bytes
    )
    st.download_button(
        "Download Case Report (PDF)",
        data=pdf_bytes,
        file_name=f"{patient_id}_case_report.pdf",
        mime="application/pdf",
        use_container_width=True
    )

# --------------------------------------------------------------------------------------
# Optional: Image Quality & Modality Check (LLM – UI only)
# --------------------------------------------------------------------------------------
st.divider()
st.header("Optional: Image Quality & Modality Check (LLM – UI only)")
qa_img = st.file_uploader(
    "Upload a JPG/PNG screenshot (NOT used for prediction). Assistant warns if non-spine.",
    type=["jpg", "jpeg", "png"], key="qa_png"
)

if qa_img:
    im = Image.open(io.BytesIO(qa_img.getvalue())).convert("RGB")
    col1, col2 = st.columns([0.55, 0.45])
    with col1:
        st.image(im, caption="Uploaded screenshot", width='stretch')
    with col2:
        st.markdown("**Local checks (no internet):**")
        st.code(json.dumps(_contrast_and_blur_metrics(im), indent=2), language="json")
        if _g_client:
            try:
                qa = _g_client.models.generate_content(
                    model="gemini-1.5-flash",
                    contents=[{
                        "role": "user",
                        "parts": [
                            {"text": "Very briefly (≤80 words), say if this looks like a SPINE MRI. "
                                     "Flag wrong region (brain/leg/etc.), low contrast or blur (general hint only)."},
                            {"inline_data": {"mime_type": "image/png",
                                             "data": base64.b64encode(_bytes_to_png(im)).decode()}}
                        ]}]
                )
                st.success(qa.candidates[0].content.parts[0].text.strip())
            except Exception as e:
                st.warning(f"LLM QA failed: {e}")
        else:
            st.caption("LLM QA disabled (no API key configured).")
